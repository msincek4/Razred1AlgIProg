#include<stdio.h>
int main()
//6. zadatak
{
    float g, kg;
    scanf("%f",&g);
    kg=g/1000;
    printf("%.2f",kg);
    return(0); 
}
