#include<stdio.h>
int main()
//1. zadatak
{
    int broj;
    scanf("%d",&broj);
    printf("%d",broj/10%10);
    return(0);
}
