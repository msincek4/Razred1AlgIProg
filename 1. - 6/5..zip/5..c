#include<stdio.h>
int main()
//5. zadatak
{
    float km, m;
    scanf("%f",&km);
    m=km*1000;
    printf("%.2f",m);
    return(0); 
}
