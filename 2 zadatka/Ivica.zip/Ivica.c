#include<stdio.h>
int main()
{
    int b1, b2, b3, b4, b5, b6 ;
    printf("unesite 6 brojeva:\n");
    scanf("%d%d%d%d%d%d", &b1, &b2, &b3, &b4, &b5, &b6);//iza svakog nesenog broja pritisnite enter
    printf("%d", b2);
    printf("%d", b4);
    printf("%d", b6);
    return(0); 
}
