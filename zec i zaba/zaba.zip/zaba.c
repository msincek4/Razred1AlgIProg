#include<stdio.h>
int main()
{
    printf("@..@(----)(>_<)^^~~^^");
    return(0);
}

