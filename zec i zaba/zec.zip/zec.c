#include<stdio.h>
int main()
{
    printf("(\\____/) \n");
    printf(" (='.'=) \n");
    printf("('')_('') ");
    return(0);
}
